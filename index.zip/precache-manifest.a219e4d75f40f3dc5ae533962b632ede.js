self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ad7dd24c88c5c57027d8ff06ff9883ce",
    "url": "/taskiton/index.html"
  },
  {
    "revision": "dc834d6e269d8a66c4ff",
    "url": "/taskiton/static/css/main.e3840836.chunk.css"
  },
  {
    "revision": "a300ecafa6c1ec813486",
    "url": "/taskiton/static/js/2.08a97cbb.chunk.js"
  },
  {
    "revision": "b51e62edbcf7a9c4f4ad13f506021d3e",
    "url": "/taskiton/static/js/2.08a97cbb.chunk.js.LICENSE"
  },
  {
    "revision": "dc834d6e269d8a66c4ff",
    "url": "/taskiton/static/js/main.50b7a422.chunk.js"
  },
  {
    "revision": "1d1c5a4e15af40c91fa9",
    "url": "/taskiton/static/js/runtime-main.96836dd4.js"
  },
  {
    "revision": "29a0444336261d80ebfaa41ffbda36bd",
    "url": "/taskiton/static/media/signupImage.29a04443.svg"
  },
  {
    "revision": "4a25697344ac94a77be6325e62240bcf",
    "url": "/taskiton/static/media/task-icons.4a256973.svg"
  }
]);